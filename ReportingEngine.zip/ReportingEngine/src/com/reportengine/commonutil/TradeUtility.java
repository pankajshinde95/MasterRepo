package com.reportengine.commonutil;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import com.reportengine.model.TradeInstruction;

/**
 * @author Pankaj_Shinde01
 *	Utilities methods for trade reporting engine
 */
public class TradeUtility {
	
	static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
	
	private TradeUtility() {
		
	}
	
	/**
	 * This method calculate and set trade amount 
	 * USD amount of a trade = Price per unit * Units * Agreed ForEx rate
	 * @param instruction
	 * 
	 */
	public static void calculateTradeAmountInUSD(TradeInstruction instruction) {
		instruction.setTradeAmount(instruction.getPricePerUnit().multiply(BigDecimal.valueOf(instruction.getUnit())
				 .multiply(instruction.getAgreedFix())));
		
	}
	
	/**
	 * Convert string to locale date
	 * @param date
	 * @return 
	 */
	public static LocalDate convertLocaleDate(String date) {
		return LocalDate.parse(date, formatter);

	}
	
	/**
	 * Convert locale date to string
	 * @param date
	 * @return date in string format
	 */
	public static String convertDateToString(LocalDate date) {
		return formatter.format(date);

	}

}
