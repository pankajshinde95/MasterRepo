package com.reportengine.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.reportengine.services.ReportGenerator;
import com.reportengine.services.TradeCalculator;


public class ExecuteTrade {
	public static void main(String[] args) {
		//instruction and settlement dates from given samples
		String fooInstructionDate = "01-Jan-2016";
		String fooSettlementDate = "02-Jan-2016";
		String barInstructionDate = "05-Jan-2016";
		String barSettlementDate = "07-Jan-2016";
		
		// another sample instruction and settlement dates
		String instructionDate = "01-Nov-2018";
		String settlementDate = "02-Nov-2018";
		String buyInstruction= "B";
		String sellInstruction = "S";
		
		// trade instruction from given sample
		TradeInstruction tradeInstruction = new TradeInstruction("FOO",buyInstruction,BigDecimal.valueOf(0.50),"SGP",fooInstructionDate,
				fooSettlementDate,200,BigDecimal.valueOf(100.25));
		
		// trade instruction from given sample
		TradeInstruction tradeInstruction2 = new TradeInstruction("BAR",sellInstruction,BigDecimal.valueOf(0.22),"AED",barInstructionDate,
				barSettlementDate,450,BigDecimal.valueOf(150.5));
		
		TradeInstruction tradeInstruction3 = new TradeInstruction("JAZZ",buyInstruction,BigDecimal.valueOf(1.3),"GBP",instructionDate,
				settlementDate,13,BigDecimal.valueOf(100));
		
		TradeInstruction tradeInstruction4 = new TradeInstruction("RAK",buyInstruction,BigDecimal.valueOf(0.18),"TRY",instructionDate,
				settlementDate,17,BigDecimal.valueOf(100));
		
		TradeInstruction tradeInstruction5 = new TradeInstruction("SEEP",buyInstruction,BigDecimal.valueOf(0.014),"INR",instructionDate,
				settlementDate,18,BigDecimal.valueOf(100));
		
		TradeInstruction tradeInstruction6 = new TradeInstruction("LIMO",buyInstruction,BigDecimal.valueOf(1),"USD",instructionDate,
				settlementDate,15,BigDecimal.valueOf(100));
		
		TradeInstruction tradeInstruction7 = new TradeInstruction("JAM",sellInstruction,BigDecimal.valueOf(0.22),"AED",instructionDate,
				settlementDate,373,BigDecimal.valueOf(10.5));
		
		List<TradeInstruction> tradeInsructions = new ArrayList<>();
		tradeInsructions.add(tradeInstruction);
		tradeInsructions.add(tradeInstruction2);
		tradeInsructions.add(tradeInstruction3);
		tradeInsructions.add(tradeInstruction4);
		tradeInsructions.add(tradeInstruction5);
		tradeInsructions.add(tradeInstruction6);
		tradeInsructions.add(tradeInstruction7);
		TradeCalculator tradeCalculator = new TradeCalculator();
		ReportGenerator report = new ReportGenerator(tradeCalculator);
		report.generateDailyReport(tradeInsructions);
	}


}
