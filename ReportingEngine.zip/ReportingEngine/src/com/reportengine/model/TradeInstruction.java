package com.reportengine.model;

import java.math.BigDecimal;

/**
 * @author Pankaj_Shinde01
 * VO class for trade instructions sent by various clients
 */
public class TradeInstruction {

	private String entity;
	private String instructionFlag;
	private BigDecimal agreedForex;
	private String currency;
	private String instructionDate;
	private String settlementDate;
	private int unit;
	private BigDecimal pricePerUnit;
	private BigDecimal tradeAmount;

	public TradeInstruction(String entity, String instructionFlag, BigDecimal agreedFix, String currency, String instructionDate,
			String settlementDate, int unit, BigDecimal pricePerUnit) {
		this.entity = entity;
		this.instructionFlag = instructionFlag;
		this.agreedForex = agreedFix;
		this.currency = currency;
		this.instructionDate = instructionDate;
		this.settlementDate = settlementDate;
		this.unit = unit;
		this.pricePerUnit = pricePerUnit;
	}

	

	/**
	 * @return the entity
	 */
	public String getEntity() {
		return entity;
	}



	/**
	 * @param entity the entity to set
	 */
	public void setEntity(String entity) {
		this.entity = entity;
	}



	/**
	 * @return the instructionFlag
	 */
	public String getInstructionFlag() {
		return instructionFlag;
	}



	/**
	 * @param instructionFlag the instructionFlag to set
	 */
	public void setInstructionFlag(String instructionFlag) {
		this.instructionFlag = instructionFlag;
	}



	/**
	 * @return the agreedFix
	 */
	public BigDecimal getAgreedFix() {
		return agreedForex;
	}



	/**
	 * @param agreedFix the agreedFix to set
	 */
	public void setAgreedFix(BigDecimal agreedForex) {
		this.agreedForex = agreedForex;
	}



	/**
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}



	/**
	 * @param currency the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}



	/**
	 * @return the instructionDate
	 */
	public String getInstructionDate() {
		return instructionDate;
	}



	/**
	 * @param instructionDate the instructionDate to set
	 */
	public void setInstructionDate(String instructionDate) {
		this.instructionDate = instructionDate;
	}



	/**
	 * @return the settlementDate
	 */
	public String getSettlementDate() {
		return settlementDate;
	}



	/**
	 * @param settlementDate the settlementDate to set
	 */
	public void setSettlementDate(String settlementDate) {
		this.settlementDate = settlementDate;
	}



	/**
	 * @return the unit
	 */
	public int getUnit() {
		return unit;
	}



	/**
	 * @param unit the unit to set
	 */
	public void setUnit(int unit) {
		this.unit = unit;
	}



	/**
	 * @return the pricePerUnit
	 */
	public BigDecimal getPricePerUnit() {
		return pricePerUnit;
	}



	/**
	 * @param pricePerUnit the pricePerUnit to set
	 */
	public void setPricePerUnit(BigDecimal pricePerUnit) {
		this.pricePerUnit = pricePerUnit;
	}



	/**
	 * @return the tradeAmount
	 */
	public BigDecimal getTradeAmount() {
		return tradeAmount;
	}



	/**
	 * @param tradeAmount the tradeAmount to set
	 */
	public void setTradeAmount(BigDecimal tradeAmount) {
		this.tradeAmount = tradeAmount;
	}



	@Override
	public String toString() {

		return "Instructions for trade [" + this.entity + ", " + this.instructionFlag + ", " + this.currency + ", "
				+ this.settlementDate + ", " + this.unit + ", " + this.pricePerUnit + "]";
	}

}
