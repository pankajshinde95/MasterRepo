package com.reportengine.model;

import java.util.Objects;

/**
 * @author Pankaj_Shinde01
 *
 */
public class EntityRank {
	private int rank;
    private  String entity;
    private  String date;
    
   public EntityRank(int rank, String entity,String date){
    	this.rank =rank;
    	this.entity =entity;
    	this.date =date;
    }
    
		
		
	/**
	 * @return the rank
	 */
	public int getRank() {
		return rank;
	}
	
	
	
	/**
	 * @param rank the rank to set
	 */
	public void setRank(int rank) {
		this.rank = rank;
	}
	
	
	
	/**
	 * @return the entity
	 */
	public String getEntity() {
		return entity;
	}
	
	
	
	/**
	 * @param entity the entity to set
	 */
	public void setEntity(String entity) {
		this.entity = entity;
	}
	
	
	
	/**
	 * @return the date
	 */
	public String getDate() {
		return date;
	}
	
	
	
	/**
	 * @param date the date to set
	 */
	public void setDate(String date) {
		this.date = date;
	}
	


	@Override
    public String toString() {
		
		return "EntityRank [" + this.entity + ", " + this.rank  + ", " + this.date + "]";
    }
	
	@Override
	public boolean equals(Object o) {
		if (o == null || getClass() != o.getClass())
			return false;
		if (this == o)
			return true;
		final EntityRank other = (EntityRank) o;
		return other.getRank() == this.getRank() && other.getEntity().equals(this.getEntity())
				&& other.getDate().equals(this.getDate());
	}

	@Override
	public int hashCode() {
		return Objects.hash(rank, entity, date);
	}

}
