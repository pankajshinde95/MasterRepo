package com.reportengine.services;

import java.time.DayOfWeek;
import java.time.LocalDate;

/**
 * @author Pankaj_Shinde01
 *
 */
public class AEDSGPWorkingDayImpl implements WorkingDay {

	/**
	 * This method contain logic to check non working 
	 * day for currency other than AER and SGP
	 * @param date
	 * @return boolean
	 */
	public boolean isNonWorkingDay(LocalDate date) {
		final DayOfWeek day = date.getDayOfWeek();
		boolean isWeekEnd =false;
		if (day == DayOfWeek.FRIDAY || day == DayOfWeek.SATURDAY) {
			isWeekEnd = true;
		}
		return isWeekEnd;
		
	}

}
