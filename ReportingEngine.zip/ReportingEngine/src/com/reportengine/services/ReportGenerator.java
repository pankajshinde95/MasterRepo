package com.reportengine.services;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

import com.reportengine.model.EntityRank;
import com.reportengine.model.TradeInstruction;

/**
 * @author Pankaj_Shinde01
 *
 */
public class ReportGenerator {
	TradeCalculator tradeCalculator;
	
	public ReportGenerator(TradeCalculator tradeCalculator) {
		this.tradeCalculator = tradeCalculator;
	}
	
	
	/**
	 * @author Pankaj_Shinde01
	 * This method prints daily report of trading
	 * @param tradeInstructions
	 */
	public void generateDailyReport(List<TradeInstruction> tradeInstructions) {
		StringBuilder stringBuilder = new StringBuilder();
		tradeCalculator.calculateUSDAmountOfTrade(tradeInstructions);
		tradeCalculator.caluclateSettlementDate(tradeInstructions);
		String lineFormatter = "---------------------------------------";
		
		stringBuilder.append("Daily Incoming Amount :");
		Predicate<TradeInstruction> sellPredicate = (TradeInstruction p) -> p.getInstructionFlag().equalsIgnoreCase("S");
		Map<String, BigDecimal> outgoingAmount = tradeCalculator.calculateDailyTradeAmount(tradeInstructions,sellPredicate);
		stringBuilder = printAmountReport(outgoingAmount,stringBuilder);
		stringBuilder.append(lineFormatter + "\n" + lineFormatter);
		stringBuilder.append("\n");
		
		stringBuilder.append("\nDaily Outgoing Amount :");
		Predicate<TradeInstruction> buyPredicate = (TradeInstruction p) -> p.getInstructionFlag().equalsIgnoreCase("B");
		Map<String, BigDecimal> incomingAmount = tradeCalculator.calculateDailyTradeAmount(tradeInstructions,buyPredicate);
		stringBuilder = printAmountReport(incomingAmount,stringBuilder);
		stringBuilder.append(lineFormatter + "\n" + lineFormatter);
		stringBuilder.append("\n");
		
		stringBuilder.append("\nDaily Incoming Entity Ranking :");
		List<EntityRank> entitySellerRanks =  tradeCalculator.calculateRanking(tradeInstructions, sellPredicate);
		stringBuilder = printEntityRanking(entitySellerRanks,stringBuilder);
		stringBuilder.append(lineFormatter + "\n" + lineFormatter);
		stringBuilder.append("\n");
		
		stringBuilder.append("\nDaily Outgoing Entity Ranking :");
		List<EntityRank> entityBuyerRanks = tradeCalculator.calculateRanking(tradeInstructions, buyPredicate);
		stringBuilder = printEntityRanking(entityBuyerRanks,stringBuilder);
		
		System.out.println(stringBuilder.toString());
		
	}
	
	private StringBuilder printAmountReport(Map<String, BigDecimal> amountReport, StringBuilder sb) {
		sb.append("\n\n");
		amountReport.forEach((date, amount) -> {
			sb.append("Date : " + date + " 	Amount : " + amount);
			sb.append("\n");
		});

		return sb;
	}
	
	private StringBuilder printEntityRanking(List<EntityRank> entityRanks,StringBuilder sb) {
		sb.append("\n");
		sb.append("Date 		Rank 		Entity");
		entityRanks.forEach(entityRank -> {
			sb.append("\n");
			sb.append(entityRank.getDate() + " 	" + entityRank.getRank() + " 		" + entityRank.getEntity());
			
		});
		sb.append("\n");
		return sb;
	}

}
