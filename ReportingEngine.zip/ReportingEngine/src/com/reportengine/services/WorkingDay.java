package com.reportengine.services;

import java.time.LocalDate;

/**
 * @author Pankaj_Shinde01
 *
 */
public interface WorkingDay {
	
	abstract boolean isNonWorkingDay(LocalDate date);
	
	/**
	 * This method contain logic to get working day
	 * @param date
	 * @return LocalDate
	 */
	public default LocalDate findWorkingDay(LocalDate date) {
		LocalDate workingDay = date;
		while (isNonWorkingDay(workingDay)) {
			workingDay = workingDay.plusDays(1);
		}
		return workingDay;
	}
	

}
